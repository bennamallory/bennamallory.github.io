# File name     : PC02_20190916_Benna_Mallory.py
# JES Version   : jes-4-3
# Purpose       : To practice basic drawing skills with turtles
# Author        : Mallory Benna 
# Date written  : 9-13-2019
# Revised       : 9-14-2019 -- additional turtles
# Description   : This program provides methods for creating an animation using turtles

#Import time and random modules
from time import sleep
from random import *

#Initialize variables
w = makeWorld()

t1 = makeTurtle(w)
t1.setPenColor(blue)
t1.setBodyColor(blue)
t1.setPenWidth(3)

t2 = makeTurtle(w)
t2.setPenColor(makeColor(52,210,235))
t2.setBodyColor(makeColor(52,210,235))
t2.setPenWidth(3)

t3 = makeTurtle(w)
t3.setPenColor(makeColor(31,129,209))
t3.setBodyColor(makeColor(31,129,209))
t3.setPenWidth(3)

t4 = makeTurtle(w)
t4.setPenColor(makeColor(56,194,37))
t4.setBodyColor(makeColor(56,194,37))
t4.setPenWidth(1)

t5 = makeTurtle(w)
t5.setPenColor(black)
t5.setBodyColor(black)
t5.setWidth(10)
t5.setHeight(10)
t5.setPenWidth(20)

i = 0
j = 0
k = 0
h = 0

lower = 0
upper = 0
duration = 0.5
width = 640
height = 480
dropPicX = 470
dropPicY = 320
leftBorderSize = 10
rightBorderSize = 620

#Methods to place turtles at start

def startTurtles():
  penUp(t1)
  penUp(t2)
  penUp(t3)
  penUp(t4)
  penUp(t5)
  moveTo(t1,205,150)
  moveTo(t2,313,320)
  moveTo(t3,418,150)

#Method to generate a random X value
def randX(lower,upper):
  x = randint(lower,upper)
  return x

#Method to generate a random Y value
def randY(lower,upper):
  y = randint(lower,upper)
  return y

#Method to make a single square
def makeSquare(turtle):
  penDown(turtle)
  for x in range(0,4):
    forward(turtle)
    turnRight(turtle)
  penUp(turtle)
  
#Method to make a small square
def makeSmallSquare(turtle):
  penDown(turtle)
  for x in range(0,4):
    forward(turtle,3)
    turnRight(turtle)
  penUp(turtle)
  
#Method to make a series of large squares
def manySquares(turtle):
  for x in range(0,7):
    makeSquare(turtle)
    turn(turtle,5)
  penUp(turtle)  

#Method to make a single triangle
def makeTriangle(turtle):
  penDown(turtle)
  for x in range(0,3):
    forward(turtle)
    turn(turtle,120)
    
#Method to make a series of triangles
def manyTriangles(turtle):
  penDown(turtle)
  for x in range(0,10):
    makeTriangle(turtle)
    turn(turtle,36)
  penUp(turtle)

#Method to drop a picture in world
def dropPic(turtle):
  penUp(turtle)
  moveTo(turtle,dropPicX,dropPicY)
  pic = makePicture(pickAFile())
  drop(turtle,pic)

#Method to layer a series of squares on top of triangle series
def secondLayer(turtle):
  for i in range(0,6):
    turnLeft(turtle)
    sleep(0.15)
    manySquares(turtle)


#Make animation

#Drop M
dropPic(t5)

#Start turtles in assigned locations
startTurtles()

#Draw three main star-like objects
#Star 1
sleep(duration)
manyTriangles(t1)

#Star 2
sleep(duration)
manyTriangles(t2)

#Star 3
sleep(duration)
manyTriangles(t3)

#Create rotating second layer on all three stars
sleep(duration)
secondLayer(t1)
secondLayer(t2)
secondLayer(t3)

#Draw the sections of small random squares around three main objects ( World Dimensions = W-640 X H -480 )

#Loop filling in bottom square section
while i < 900:
  #Left side
  #Bottom square
  moveTo(t4,randX(leftBorderSize,150),randY(300,450))
  makeSmallSquare(t4)
  
  #Right Side
  #Bottom square
  moveTo(t4, randX(470,rightBorderSize), randY(300,450))
  makeSmallSquare(t4)
  
  #Increase while loop by 1 each round
  i += 1
  
#Loop filling in middle rectangle section
while k < 500:
  #Left Middle rectangle
  moveTo(t4, randX(leftBorderSize,55), randY(80,300))
  makeSmallSquare(t4)
  
  #Right Middle rectangle
  moveTo(t4, randX(565,rightBorderSize), randY(80,300))
  makeSmallSquare(t4)
  
  #Increase while loop by 1 each round
  k += 1

#Loop filling in top square section
while h < 300:
  #Top Left square
  moveTo(t4, randX(leftBorderSize,85), randY(10,80))
  makeSmallSquare(t4)
  
  #Top Right square
  moveTo(t4, randX(545,rightBorderSize), randY(10,80))
  makeSmallSquare(t4)
  
  #Increase while loop by 1 each round
  h += 1
  
  
#Wipe out entire screen with scribbles after waiting
sleep(1.5)
#Blackout screen --> Move turtle to random points while drawing lines between each point
while j < 5000:
  penDown(t5)
  moveTo(t5, randX(0,width), randY(0,height))
  j += 1
